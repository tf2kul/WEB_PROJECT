<!--<?php
    session_start();
    if(!isset($_SESSION['id'])){
        echo '<script>
        alert("접근권한이 없습니다");
        
        </script>';

        echo "<script> window.close(); 
self.close(); 
window.opener = window.location.href; 
self.close(); 
window.open('about:blank','_self').close(); </script>"; 
    }
?>-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>create cafe</title>
    <script  src="http://code.jquery.com/jquery-latest.min.js"></script>

<script>
    function sub(){
        
    }
	

</script>
</head>
<body>
   <form action="create.php" method="POST">
 <input type="hidden" name ="admin" maxlength="100" value="<?=$_SESSION['id']?>"><br>
    cafe name: </br><input type="text" name ="name" maxlength="200"><br>
    cafe : </br><input type="text" name ="exp" maxlength="100"><br>
    cafe url: </br><input type="text" name ="url" maxlength="100"><br>
    <!--<input type="button" value="중복확인" onclick="javascript:sub();" >-->
    <input type="submit" value="생성">
    </form>
</body>
</html>
