<!--<?php
    session_start();
    if(!isset($_SESSION['id'])){
        echo '<script>
        alert("접근권한이 없습니다");
        
        </script>';

        echo "<script> window.close(); 
self.close(); 
window.opener = window.location.href; 
self.close(); 
window.open('about:blank','_self').close(); </script>"; 
    }
?>-->
<?php
include "db_con.php";
/*$cadmin = $_POST['cadmin'];*/
$cname = $_POST['cname'];
$cexp = $_POST['cexp'];
$curl = $_POST['curl'];

$stmt_name = $db ->prepare('select * from cafe where cname=:cname');
$stmt_name->bindParam(':cname',$cname);
$stmt_name->execute();
$row_name->$stmt_name->fetch(PDO::FETCH_ASSOC);
$stmt_nk = $db-> perpare('select * from cafe where curl=:curl');
$stmt_nk->bindParam(':curl',$curl);
$stmt_nk->execute();
$row_url = $stmt_nk->fetch(PDO::FETCH_ASSOC);

/*

    
$last = $db->query($query);
$last -> setFetchMode(PDO::FETCH_ASSOC);
*/

if($cname == null) {
    echo ("name 입력하세요");
    exit();
}
elseif($cexp == null) {
    echo ("exp를 입력하세요");
    exit();
}
elseif($curl == null) {
    echo ("url 입력하세요");
    exit();
}
elseif($row_name > 0){
    echo ("중복된 이름");
    exit();
}
elseif($row_url > 0){
    echo ("중복된 url입니다");
        exit();
}

/*while($i=$last ->fetch()){
if($name==row['cname'] || url==row['curl'] || empty($name) || empty($exp) || empty($curl)) 
    {
        echo "<meta http-equiv='refresh' content='0; url=./error.php'>";
        exit;
   
    }
}*/
/*if(empty($cname) || empty($cexp) || empty($curl)) 
{
    echo "여백이 존재.";
    exit;
}*/

else {                      
/* $query = "INSERT INTO cafe(cadmin,cname, cexp, curl) VALUES ('$cadmin','$cname', '$cexp', '$curl')";


$db->query($query);
echo "<meta http-equiv='refresh' content='0; url=./index.php'>";
    */
/*$hash = hash('sha512' , $username)*/
    $stmt = $db->prepare("insert into cafe (cname, cexp,curl) values (:cname, :cexp ,:curl)");
    $stmt->blindParam(':cname',$cname);
    $stmt->blindParam(':cexp',$cexp);
    $stmt->blindParam(':curl',$curl);
    $stmt->execute();
}
?>