<?php
	include "db_con.php";
    
    $query="SELECT * FROM cafe ORDER BY id DESC";
/*    $result -> query($query);*/
    $result = mysql_query($query, $db);
    /*$result = mysql_query($query);
    $result -> query($query);
    */$total = mysql_affected_rows();

    $pagesize = 5;
?>
/*
<html>
<head>
    <meta charset="UTF-8">
    <title>리스트</title>
</head>
<body>



<?php 
 for($i=$_GET[1] ; $i < $_GET[1]+$pagesize ; $i++) {
     if ($i < $total)
     {
         mysql_datacheck($result,$i);
         $row = mysql_fetch_array($result);
     

?>
<table>
    <tr>
        <td>idx <?=$row[idx]?> </td>
        <td>카페명<?=$row[name] ?></td>
        <td>url주소<?=$row[url] ?></td>
        <td>설명<?=$row[info] ?></td>
        <td>카페설립자<?=$row[cadmin] ?></td>
        <td><a href="delete.php?id=<?=row[id]?>">삭제</a></td>
    </tr>
    <tr>
        <td COLSPAN=4><?=$row[content]?></td>
    </tr>
</table>

<?php
            }
        }
        $prev = $_GET[no] -$pagesize;
        $next = $_GET[no] +$pagesize;
        
        if($prev >= 0) {
            echo("<a href='$_SERVER[PHP_SELF]?no=$prev'>이전</a>");
        }
        if($next < $total) {
            echo("<a href='$_SERVER[PHP_SELF]?no=$next'>다음</a>");
        }

?>
</body>
</html>