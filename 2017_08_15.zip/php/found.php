<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div class="wrap">
        <form action="../php/forget.php" method="POST" >
            <input type="text" name="name" id="name" >
            <input type="email" name="email" id="email">            
            <button type="button">아이디 찾기</button>
            <button type="button" id="submit_pw">비밀번호찾기</button>
        </form>
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script> 
<script>
    $("#submit_pw").on("click",function () {
        $(this).attr("type","submit");    
    })
</script>
</html>