<?php
include('db_con.php');

session_start();

if(empty($_SESSION['id'])) {
    echo "로그인을 하지 않았습니다";
    echo "<script>location.href='../HTML/index.html';</script>";
}
session_unset();
session_destroy();
echo "로그아웃 하였습니다";

?>
<script>
location.href="../HTML/index.html";
</script>