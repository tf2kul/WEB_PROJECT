<?php

include('db_con.php');
session_start();
$good_login = 0;
$id = $_POST['id'];
$pw = $_POST['pw'];


if(empty($id) || empty($pw)) {
    echo "아이디나 비밀번호를 치세요<br>";
    exit;
}

//$id= mysql_real_escape_string($id);

$id = preg_replace("/[ #\&\+\-%@=\/\\\:;,\.'\"\^`~\_|\!\?\*$#<>()\[\]\{\}]/i", "", $id);
$pw = preg_replace("/[ #\&\+\-%@=\/\\\:;,\.'\"\^`~\_|\!\?\*$#<>()\[\]\{\}]/i", "", $pw);
$id=addslashes($id);
$pw=addslashes($pw);

$hash_pw = hash('sha512',$pw);
$query = "SELECT * from user";
//$query = "SELECT * from login WHERE id==$id and pw==$pw";
$last = $db->query($query);
$last->setFetchMode(PDO::FETCH_ASSOC);

while($row= $last->fetch()){
if($id == $row['id'] && $hash_pw == $row['pw']) {
	$good_login = 1;
	break;
	}
}
if($good_login) {
	echo "Login Success !"."<br>";
    $_SESSION['id'] = $id;
    echo "당신의 이름은: ".$_SESSION['id']."<br>";
    print "<html>";
    print "<head>";
    print "<title>";
    print "</title>";
    print "</head>";
    print "<body>";
    print "<form action=logout.php method=post>";
    print "<button type=submit>로그아웃</button>";
    print "</form>";
    print "</body>";
    print "</html>";
	exit;
}
else {
	echo "G00d..bye..";
	exit;
}

?>
