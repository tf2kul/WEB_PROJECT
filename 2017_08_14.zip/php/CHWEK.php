<?php

$WAL = date("n");
$OIL = date("j");
echo $WAL;
echo "<br>";

$date_s = 1;

while($date_s<=$OIL) {
    echo $date_s."  ";
    $date_s+=1;
}

?>